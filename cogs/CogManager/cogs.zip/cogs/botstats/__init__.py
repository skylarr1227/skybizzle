from redbot.core.bot import Red

from cog_shared.swift_libs.checks import try_import
from cog_shared.swift_libs.setup import setup_cog


async def setup(bot: Red):
    try_import("datadog")
    await setup_cog(bot, "BotStats")

    from .botstats import BotStats
    import datadog

    cog = BotStats(bot)
    datadog.initialize(statsd_host=await cog.config.host())
    cog.interval = await cog.config.interval()
    cog.prefix = await cog.config.prefix()
    if bot.uptime:
        cog.task = bot.loop.create_task(cog.stats_task())

    bot.add_cog(cog)
