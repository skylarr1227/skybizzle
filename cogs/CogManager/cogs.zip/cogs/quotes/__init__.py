from redbot.core.bot import Red

from cog_shared.swift_libs.setup import setup_cog
from quotes.quotes import Quotes


async def setup(bot: Red):
    await setup_cog(bot, "Quotes")
    bot.add_cog(Quotes(bot))
