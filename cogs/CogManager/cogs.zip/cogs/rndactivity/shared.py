from cog_shared.swift_libs.translations import Translations

translate = Translations(__file__)
