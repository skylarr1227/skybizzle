from redbot.core.bot import Red

from cog_shared.swift_libs.setup import setup_cog
from cog_shared.swift_libs.checks import try_import


async def setup(bot: Red):
    try_import("babel")
    from rndactivity.rndactivity import RNDActivity

    await setup_cog(bot, "RNDActivity")
    bot.add_cog(RNDActivity(bot))
