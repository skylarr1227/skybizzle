from datetime import datetime
from functools import partial
from statistics import mean
from typing import Tuple, Callable, Any, Iterable

from babel.dates import format_timedelta
from redbot.core.bot import Red

from rndactivity.shared import translate


def placeholder(func):
    setattr(func, "is_placeholder", True)
    return func


class Placeholders:
    def __iter__(self) -> Iterable[Tuple[str, Callable[[], Any]]]:
        for k, v in self.__class__.__dict__.items():
            if not k.startswith("_") and hasattr(v, "is_placeholder"):
                yield k, partial(v, self)

    def __str__(self):
        return "\n".join(
            f"**`{{{k}}}`** \N{EM DASH} {translate('placeholders', k)}" for k in dict(self).keys()
        )

    def __init__(self, bot: Red, shard: int):
        self._bot = bot
        self._shard_id = shard

    @placeholder
    def servers(self) -> int:
        return len([x for x in self._bot.guilds if x.shard_id == self._shard_id])

    @placeholder
    def shard(self) -> int:
        return self._shard_id + 1

    @placeholder
    def shards(self) -> int:
        return self._bot.shard_count

    @placeholder
    def playing_music(self) -> int:
        import lavalink

        return len(lavalink.active_players())

    @placeholder
    def members(self):
        return sum(len(x.members) for x in self._bot.guilds)

    @placeholder
    def users(self):
        return len(self._bot.users)

    @placeholder
    def channels(self):
        return sum(len(x.channels) for x in self._bot.guilds)

    @placeholder
    def avg_members(self):
        return mean(x.member_count for x in self._bot.guilds)

    @placeholder
    def max_members(self):
        return max(x.member_count for x in self._bot.guilds)

    @placeholder
    def uptime(self):
        return format_timedelta(
            datetime.utcnow() - self._bot.uptime, locale=translate.babel, format="narrow"
        )
