from .sketch import Sketch

def setup(bot):
    bot.add_cog(Sketch(bot))
