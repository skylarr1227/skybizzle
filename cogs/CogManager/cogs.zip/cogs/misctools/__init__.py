from redbot.core.bot import Red

from cog_shared.swift_libs.setup import setup_cog
from cog_shared.swift_libs.checks import try_import


async def setup(bot: Red):
    try_import("babel", "tzlocal")
    from misctools.misctools import MiscTools

    await setup_cog(bot, "MiscTools")
    cog = MiscTools(bot)
    bot.add_cog(cog)
    try:
        await cog.setup_toolsets()
    except Exception:
        bot.remove_cog("MiscTools")
        raise
