import re
from collections import namedtuple

import discord
from redbot.core import checks
from redbot.core.utils.chat_formatting import error

from misctools import commands
from misctools.shared import translate as translate_, log
from misctools.toolset import Toolset

translate = translate_.sub("channelcontact")
fake_message = namedtuple("Message", "guild")
MENTION = re.compile(r"<@!?[0-9]{17,21}> ?")


class ChannelContact(Toolset, i18n=translate):
    orig_contact: commands.Command
    setup_first = True

    def __tool_setup(self):
        self.orig_contact = self.bot.get_command("contact")
        if self.orig_contact:
            self.bot.remove_command(self.orig_contact.qualified_name)
        self.register_defaults(contact_channel=None)

    def __tool_cleanup(self):
        if self.orig_contact:
            self.bot.add_command(self.orig_contact)
        else:
            self.bot.add_command(self.bot.get_cog("Core").contact)

    @commands.command()
    # red's default contact command has a cooldown of once every minute, but since we're sending
    # these to a channel, we can be a little more lax with the cooldown.
    @commands.cooldown(3, 90, commands.BucketType.user)
    @translate.command("help.contact")
    async def contact(self, ctx: commands.Context, *, message: str):
        channel = self.bot.get_channel(await self.config.contact_channel())
        if not channel:
            await ctx.send(translate("cannot_deliver_no_channel"))
            return

        guild = ctx.message.guild
        author = ctx.message.author
        footer = translate("user_id", id=author.id)

        if ctx.guild is not None:
            footer = " | ".join([footer, translate("guild_id", id=guild.id)])

        prefixes = await ctx.bot.command_prefix(ctx.bot, fake_message(guild=channel.guild))
        # attempt to skip prefixes added by --mentionable
        prefix = next((x for x in prefixes if not MENTION.match(x)), prefixes[0])
        # if there are no other prefixes, clean it up to be a little prettier in a code block
        if MENTION.match(prefix):
            prefix = f"@{ctx.bot.user!s} "

        origin = translate(
            "contacted_by", "dm" if ctx.guild is None else "guild", user=author, guild=ctx.guild
        )
        content = translate("reply_instructions", prefix=prefix, id=author.id)
        colour = author.colour if isinstance(author, discord.Member) else ctx.embed_colour()

        e = discord.Embed(colour=colour, description=message)
        if author.avatar_url:
            e.set_author(name=origin, icon_url=author.avatar_url)
        else:
            e.set_author(name=origin)
        e.set_footer(text=footer)

        try:
            await channel.send(content, embed=e)
        except discord.HTTPException:
            log.exception("Failed to send a contact message")
            await ctx.send(translate("cannot_deliver_unknown"))
        else:
            await ctx.send(translate("message_sent"))

    @commands.command()
    @checks.is_owner()
    @translate.command("help.contact_channel")
    async def contactchannel(self, ctx: commands.Context, channel: discord.TextChannel):
        if not channel.permissions_for(channel.guild.me).embed_links:
            return await ctx.send(error(translate("no_embed_perms")))
        await self.config.contact_channel.set(channel.id)
        await ctx.send(translate("contact_channel_set", channel=channel.mention))
