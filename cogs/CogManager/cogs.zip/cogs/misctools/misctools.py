from contextlib import suppress
from typing import Type, List, Optional

import discord
from babel.lists import format_list
from redbot.core import commands, checks
from redbot.core.bot import Red
from redbot.core.utils.chat_formatting import pagify, inline

from misctools.shared import translate, log, config
from misctools.tools import toolsets
from misctools.toolset import Toolset

loaded: List[Toolset] = []


def find_toolset(toolset: str) -> Optional[Type[Toolset]]:
    return discord.utils.find(lambda x: x.__name__.lower() == toolset.lower(), toolsets)


@translate.cog("help.cog")
class MiscTools(commands.Cog):
    def __init__(self, bot: Red):
        super().__init__()
        self.bot = bot
        self.__cog_commands__ = self.known_commands()

    def cog_unload(self):
        log.debug("Cog is unloading, tearing down loaded toolsets")
        for toolset in loaded:
            try:
                toolset.unload_toolset()
            except Exception as e:  # pylint:disable=broad-except
                log.exception("Failed to unload toolset %r", toolset, exc_info=e)

    async def load_toolset(self, toolset: Toolset):
        if any(type(x).__name__ == type(toolset).__name__ for x in loaded):
            return

        loaded.append(toolset)
        await toolset.load_toolset(self)
        self.__cog_commands__ = self.known_commands()

    @classmethod
    def known_commands(cls):
        cmds = [x for x in cls.__dict__.values() if isinstance(x, commands.Command)]
        for toolset in loaded:
            cmds.extend([x for x in toolset.commands()])
        return cmds

    async def setup_toolsets(self):
        """Setup configured toolsets on cog load"""
        to_load = await config.toolsets()
        loaded_ = []
        for name in to_load:
            load = find_toolset(name)
            if not load:
                log.warning("Failed to locate any toolset with the name %r", name)
                async with config.toolsets() as ts_cfg:
                    ts_cfg.remove(name)
                continue
            loaded_.append(load.__name__.lower())

            try:
                await self.load_toolset(load(self.bot))
            except Exception as e:
                self.cog_unload()
                raise RuntimeError(
                    f"Failed to load toolset {load.__name__!r}; treating as a fatal error."
                ) from e
        if loaded_:
            log.info("Loaded toolsets: %s", ", ".join(loaded_))

    @commands.group(aliases=["tools", "toolset"])
    @checks.is_owner()
    @translate.command("help.misctools")
    async def misctools(self, ctx: commands.Context):
        pass

    @misctools.command(name="info", aliases=["show"])
    @translate.command("help.info")
    async def misctools_info(self, ctx: commands.Context, toolset: str):
        toolset = find_toolset(toolset)
        if not toolset:
            await ctx.send(translate("toolset_not_found"))
            return

        embed = discord.Embed(
            colour=await ctx.embed_colour(), description=str(toolset.tool_description)
        )
        embed.set_author(
            name=translate("toolset_info"), icon_url=self.bot.user.avatar_url_as(format="png")
        )
        embed.add_field(
            name=translate("commands"),
            value="\n".join(
                [
                    f"**{ctx.prefix}{x.qualified_name}** \N{EM DASH} {x.short_doc!s}"
                    for x in toolset.commands()
                    if (
                        (not x.parent or isinstance(x.parent, Red))
                        and not x.hidden
                        and await x.can_run(ctx)
                    )
                ]
            ),
        )
        await ctx.send(embed=embed)

    @misctools.command(name="list")
    @translate.command("help.list")
    async def misctools_list(self, ctx: commands.Context):
        message = ""
        unloaded = [x for x in toolsets if not any(z.__class__ == x for z in loaded)]

        if loaded:
            message += "\n\n".join(
                [
                    translate("loaded_sets"),
                    # shut up pylint, `x` does have a `short_desc` attribute.
                    # pylint:disable=no-member
                    "\n".join(f"+ {type(x).__name__} \N{EM DASH} {x.short_desc()}" for x in loaded),
                    # pylint:enable=no-member
                ]
            )

        if loaded and unloaded:
            message += "\n\n"

        if unloaded:
            message += "\n\n".join(
                [
                    translate("unloaded_sets"),
                    "\n".join(f"- {x.__name__} \N{EM DASH} {x.short_desc()}" for x in unloaded),
                ]
            )

        await ctx.send_interactive(pagify(message), box_lang="diff")

    @misctools.command(name="load", aliases=["enable", "add"], usage="<toolsets...>")
    @translate.command("help.load")
    async def misctools_load(self, ctx: commands.Context, *toolsets_: str):
        if not toolsets_:
            await ctx.send_help()
            return

        loaded_ = []
        output = []

        for toolset in toolsets_:
            toolset_ = toolset
            toolset = find_toolset(toolset)
            if not toolset:
                output.append(translate("toolset_not_found", set=toolset_))
                continue

            if any(x.__class__.__name__ == toolset.__name__ for x in loaded):
                output.append(translate("toolset_already_loaded", set=toolset_))
                continue

            toolset = toolset(self.bot)
            try:
                await self.load_toolset(toolset)
            except Exception as e:  # pylint:disable=broad-except
                log.exception("Failed to load toolset %s", toolset_, exc_info=e)
                toolset.unload_toolset()
                with suppress(StopIteration, ValueError):
                    loaded.remove(
                        next(x for x in loaded if x.__class__.__name__ == toolset.__name__)
                    )
                output.append(translate("toolset_errored", set=toolset_))

            async with config.toolsets() as toolsets_:
                if type(toolset).__name__ not in toolsets_:
                    toolsets_.append(type(toolset).__name__)
            loaded_.append(toolset_)

        if loaded_:
            output.append(
                translate(
                    "toolset_loaded",
                    count=len(loaded_),
                    sets=format_list([inline(x) for x in loaded_]),
                )
            )

        for page in pagify("\n".join(output)):
            await ctx.send(page)

    @misctools.command(name="unload", aliases=["disable", "remove"], usage="<toolsets...>")
    @translate.command("help.unload")
    async def misctools_unload(self, ctx: commands.Context, *toolsets_: str):
        unloaded = []
        output = []

        for toolset in toolsets_:
            toolset_ = toolset
            toolset = find_toolset(toolset)
            if not toolset:
                output.append(translate("toolset_not_found", set=toolset_))
                continue

            if not any(x.__class__.__name__ == toolset.__name__ for x in loaded):
                output.append(translate("toolset_already_unloaded", set=toolset_))
                continue

            for x in loaded.copy():
                if x.__class__ == toolset:
                    x.unload_toolset()
                    loaded.remove(x)

            async with config.toolsets() as toolsets_:
                if type(toolset).__name__ in toolsets_:
                    toolsets_.remove(type(toolset).__name__)
            unloaded.append(toolset_)

        if unloaded:
            output.append(
                translate(
                    "toolset_unloaded",
                    count=len(unloaded),
                    sets=format_list([inline(x) for x in unloaded]),
                )
            )

        self.__cog_commands__ = self.known_commands()
        for page in pagify("\n".join(output)):
            await ctx.send(page)
