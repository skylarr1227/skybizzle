from typing import Dict, Any, List, Optional, ClassVar

import discord
from redbot.core import Config, commands
from redbot.core.bot import Red

from cog_shared.swift_libs.translations import LazyStr
from misctools.commands import _CommandMixin
from misctools.shared import config, translate, log

defaults: Dict[str, Dict[str, Any]] = {Config.GLOBAL: {"toolsets": []}}


def rebuild_defaults() -> None:
    for scope, values in defaults.items():
        config.register_custom(scope, **values)


class Toolset:
    __cog = None
    tool_description: ClassVar[Optional[LazyStr]] = None
    # If this is True, toolset_setup will be called before adding any commands.
    # This can be useful for replacing already registered commands.
    setup_first: ClassVar[bool] = False

    def __init__(self, bot: Red):
        self.bot = bot
        self.config = config

    def __init_subclass__(cls, **kwargs):
        not_using_mt = [
            x
            for x in cls.__dict__.values()
            if isinstance(x, commands.Command) and not isinstance(x, _CommandMixin)
        ]
        if any(not_using_mt):
            raise RuntimeError(
                "One or more of this toolset's commands do not use the MiscTools command classes"
            )
        if "i18n" in kwargs and "__description__" in kwargs["i18n"]:
            kwargs.setdefault("description", kwargs["i18n"].lazy("__description__"))
        cls.tool_description = kwargs.get("description", translate.lazy("no_description"))
        translator = kwargs.get("i18n", None)
        (translator or translate).attach_to_commands(cls)

    @classmethod
    def short_desc(cls):
        return cls.tool_description.split("\n")[0]

    @classmethod
    def commands(cls) -> List[commands.Command]:
        # noinspection PyTypeChecker
        return [cmd for cmd in cls.__dict__.values() if isinstance(cmd, commands.Command)]

    @staticmethod
    def register_defaults(scope: str = Config.GLOBAL, **kwargs):
        if scope not in defaults:
            defaults[scope] = {}
        defaults[scope].update(kwargs)
        rebuild_defaults()

    async def load_toolset(self, cog):
        if self.__cog is not None:
            return
        if self.setup_first:
            await discord.utils.maybe_coroutine(self.toolset_setup)

        cmds = []
        for cmd in self.commands():
            if cmd.parent:
                continue
            cmds.append(cmd)
            if isinstance(cmd, commands.Group):
                cmds.extend(cmd.walk_commands())

        self.__cog = cog
        for command in cmds:
            # pylint:disable=protected-access
            command._actual_self = self
            command._appear_from = cog
            # pylint:enable=protected-access

            log.debug("adding command %r", command.qualified_name)
            # don't bother adding commands that belong to a command group, since they'll
            # be added when we add their parent group
            if not command.parent:
                self.bot.add_command(command)
            # this event isn't dispatched by add_command on 3.1, which completely
            # renders Permissions and [p]command disable unable to restrict commands
            # added by toolsets without dispatching this event ourselves
            self.bot.dispatch("command_add", command)

        if not self.setup_first:
            await discord.utils.maybe_coroutine(self.toolset_setup)

    def unload_toolset(self):
        if not self.__cog:
            return

        for command in list(self.bot.all_commands.values()):
            if (
                command.cog is self.__cog
                and (not command.parent or isinstance(command.parent, Red))
                and any(x.qualified_name == command.qualified_name for x in self.commands())
            ):
                self.bot.remove_command(command.qualified_name)

        self.toolset_cleanup()
        self.__cog = None

    def toolset_setup(self):
        """Internal hook to listen to on toolset setup, comparable to __init__

        By default, this calls your __tool_setup method if it exists.

        This method may be async.
        """
        func = getattr(self, f"_{self.__class__.__name__}__tool_setup", None)
        if func:
            return func()

    def toolset_cleanup(self):
        """Internal hook to listen to on toolset unload, comparable to cog_unload

        By default, this calls your __tool_cleanup method if it exists.

        This method must not be async.
        """
        func = getattr(self, f"_{self.__class__.__name__}__tool_cleanup", None)
        if func:
            return func()
