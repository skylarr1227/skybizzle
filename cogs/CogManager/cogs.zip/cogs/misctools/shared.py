import argparse
import logging

from redbot.core import commands, Config

from cog_shared.swift_libs.translations import Translations
from cog_shared.swift_libs.translations.icu import ICULocale
from cog_shared.swift_libs.translations.toml import TOMLLoader

translate = Translations(__file__, loader=TOMLLoader, locale_type=ICULocale)
log = logging.getLogger("red.misctools")

try:
    config = Config.get_conf(
        None, cog_name="MiscTools", identifier=421412412, force_registration=True
    )
    config.register_global(toolsets=[])
except RuntimeError:
    config = None


class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise commands.BadArgument(message)
