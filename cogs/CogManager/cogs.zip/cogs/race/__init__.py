from .race import Race


def setup(bot):
    bot.add_cog(Race())
