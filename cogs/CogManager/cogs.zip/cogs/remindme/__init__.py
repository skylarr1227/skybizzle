from cog_shared.swift_libs.checks import try_import
from cog_shared.swift_libs.setup import setup_cog


async def setup(bot):
    try_import("babel", "tzlocal")
    from .remindme import RemindMe

    await setup_cog(bot, "RemindMe")
    bot.add_cog(RemindMe(bot))
